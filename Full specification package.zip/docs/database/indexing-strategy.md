# Indexing Strategy

Projection indexes and query optimization guidance.
