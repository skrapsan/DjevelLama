# Platform Overview

Defines overall platform architecture, bounded contexts, source-of-truth XML strategy, projection model and workspace architecture.
