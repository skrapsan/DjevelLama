# Reference System

Rules, lore, procedures, house rules and knowledge-base architecture.
