# Application Shell

Navigation rail, search, command palette and notifications.
