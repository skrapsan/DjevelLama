# Dashboard Workspace

Widget-based command center.
