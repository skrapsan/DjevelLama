# Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)

This repository documentation is intended to be licensed under CC BY-SA 4.0.

Human-readable summary:
- Attribution required
- Derivatives allowed
- Commercial use allowed
- Share adaptations under the same license

Refer to the official license text at https://creativecommons.org/licenses/by-sa/4.0/ before publication.

Note: Software source code should normally use a software license such as MIT, Apache-2.0 or GPL. CC BY-SA is best suited for documentation, specifications and design material.
