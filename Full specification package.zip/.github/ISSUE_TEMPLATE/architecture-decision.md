---
name: Architecture decision
about: Propose architectural changes
---

## Context

## Decision

## Consequences
